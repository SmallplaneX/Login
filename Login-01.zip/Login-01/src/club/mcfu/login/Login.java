package club.mcfu.login;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.*;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.Vector;

import java.util.ArrayList;

public class Login extends JavaPlugin implements Listener {
    private ArrayList<String> playerNameList = new ArrayList();//未登入玩家列表
    Vector x;
    @Override
    public void onEnable() {
        this.getLogger().info(ChatColor.GREEN+"-----------------------插件已开启------------------");
        Bukkit.getPluginManager().registerEvents(this,this);
    }
    @Override
    public void onDisable() {
        this.getLogger().info(ChatColor.RED+"-------------------------插件已关闭-----------------");
    }
    @EventHandler
    public void logInPlayer (PlayerJoinEvent player){//监听玩家登入
        if (!playerNameList.contains(player.getPlayer().getName())){//判断是否登入
            playerNameList.add(player.getPlayer().getName());//如果没有登录，就记录下来
        }
    }
    @EventHandler
    public void movePlayer(PlayerMoveEvent player){//监听玩家移动
        x = player.getPlayer().getVelocity();
        if(playerNameList.contains(player.getPlayer().getName())){
                player.setCancelled(true);
            player.getPlayer().setVelocity(new Vector(0,0,0));
        }
    }
    @EventHandler
    public void action (PlayerInteractEvent player){//监听交互
        if (playerNameList.contains(player.getPlayer().getName())){
            player.setCancelled(true);
        }
    }
    @EventHandler
    public void deliver (PlayerPortalEvent player){//监听传送门
        if(playerNameList.contains(player.getPlayer().getName())){
            player.setCancelled(true);
        }
    }
    @EventHandler
    public void throwOut (PlayerInteractEntityEvent player){//监听点击
        if(playerNameList.contains(player.getPlayer().getName())){
            player.setCancelled(true);
        }
    }
    @EventHandler
    public void throwOut (PlayerTeleportEvent player){//监听传送
        if(playerNameList.contains(player.getPlayer().getName())){
            player.setCancelled(true);
        }
    }
    @EventHandler
    public void throwOut (PlayerDropItemEvent player){//监听扔出
        if(playerNameList.contains(player.getPlayer().getName())){
            player.setCancelled(true);
        }
    }
    @EventHandler
    public void registered (PlayerCommandPreprocessEvent player){//监听指令
        if(playerNameList.contains(player.getPlayer().getName())){
            player.setCancelled(true);
        }
    }
}
